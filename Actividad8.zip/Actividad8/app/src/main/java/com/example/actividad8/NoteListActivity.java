package com.example.actividad8;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.actividad8.adapters.NotesRecyclerViewAdapter;
import com.example.actividad8.models.Note;
import com.example.actividad8.utils.SpacingltemDecorator;
import java.util.ArrayList;

public class NoteListActivity extends AppCompatActivity implements NotesRecyclerViewAdapter.OnNoteListener {

    private static final String TAG = " NoteListActivity";

    private RecyclerView mRecyclerView;
    private ArrayList<Note> mNotes = new ArrayList<>();
    private NotesRecyclerViewAdapter mNotesRecyclerViewAdapter;

    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mRecyclerView = findViewById(R.id.recyclerView);
        initRecyclerView();
        insertarDatosDePrueba();
        setSupportActionBar((Toolbar) findViewById(R.id.toolbarNote));
    }

    public void initRecyclerView(){
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(linearLayoutManager);
        SpacingltemDecorator itemDecorator= new SpacingltemDecorator(20);
        mRecyclerView.addItemDecoration(itemDecorator);
        mNotesRecyclerViewAdapter = new NotesRecyclerViewAdapter(mNotes, this);
        mRecyclerView.setAdapter(mNotesRecyclerViewAdapter);

    }

    public void insertarDatosDePrueba(){
        for (int i = 0; i < 50; i++){
            Note note  = new Note();
            note.setTitle("TITULO" + i);
            note.setContent("TEXTO DE LA NOTA" + i);
            note.setTimestamp("OCTUBRE DE 2020");
            mNotes.add(note);
        }
        mNotesRecyclerViewAdapter.notifyDataSetChanged();
    }

    @Override
    public void onNoteClick(int position) {
        Log.d(TAG, "onNoteClick: Usted hizo click en el elemento" + position + "de  la lista");
        Intent intent = new Intent(NoteListActivity.this, NoteActivity.class);
        intent.putExtra("selected_note", mNotes.get(position));
        startActivity(intent);
    }
}
