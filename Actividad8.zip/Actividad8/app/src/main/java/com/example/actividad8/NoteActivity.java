package com.example.actividad8;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.actividad8.models.Note;

public class NoteActivity extends AppCompatActivity implements View.OnTouchListener, GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener {

    private static final String TAG = "NoteActivity";

private TextView txtNoteTitle;
    private TextView txtNoteTimestamp;
    private EditText txtNoteContent;

    private boolean mIsNewNote;
    private Note mInitialNote;
    private GestureDetector gestureDetector;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);
         txtNoteTitle = findViewById(R.id.txtNoteTitle);
         txtNoteTimestamp = findViewById(R.id.txtNoteTimestamp);
         txtNoteContent = findViewById(R.id.txtNoteContent);

        if (getIncomingIntent()){
            setNewNoteProperties();
        }else{
            setNewNoteProperties();
        }

    }

    private void setNoteProperties(){
        txtNoteTitle.setText(mInitialNote.getTitle());
        txtNoteTimestamp.setText(mInitialNote.getTimestamp());
        txtNoteContent.setText(mInitialNote.getContent());
    }

    private void setNewNoteProperties(){
        txtNoteTitle.setText("Note title");
        txtNoteTimestamp.setText("Note timestamp");
        txtNoteContent.setText("Note Content");
    }

    public boolean getIncomingIntent(){
        if (getIntent().hasExtra("selected_note" )){
          mInitialNote = getIntent().getParcelableExtra("selected_note");
          mIsNewNote = false;
          return false;

        }

        mIsNewNote = true;
        return true;
    }

    public void setListener(){
        txtNoteContent.setOnTouchListener(this);
        gestureDetector = new GestureDetector(this, this );
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onDown(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        return false;
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        return gestureDetector.onTouchEvent(motionEvent);
    }
}